transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vcom -93 -work work {C:/Data/Unif/Master 1/MicroElec/Lab/Lab1/vga.vhd}

