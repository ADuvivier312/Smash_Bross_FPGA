library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_misc.all;

entity boost is
port (
		ctrl1 	: in std_logic_vector(11 downto 0) := "000000000000";
		ctrl2 	: in std_logic_vector(11 downto 0) := "000000000000";
		CLK_BOOST : in std_logic;
		player1_x : in integer range 0 to 800;
		player1_y : in integer range 0 to 600;
		player2_x : in integer range 0 to 800;
		player2_y : in integer range 0 to 600;
		game_state : in integer range 0 to 10;
		
		player1_boost_output : buffer std_logic_vector(3 downto 0) := "0000";
		player2_boost_output : buffer std_logic_vector(3 downto 0) := "0000";
		
		boost_x : buffer integer range 0 to 800;
		boost_y : buffer integer range 0 to 600;
		boost_active: buffer std_logic_vector(3 downto 0) := "0000"
		
		);
end entity boost;

architecture boost_arch of boost is

	signal boost_max_cooldown : integer range 300 to 500 := 400;
	signal boost_cooldown : integer range 0 to 500 := 0;
	signal boost_select : integer range 0 to 3 := 3;
	signal boost_select_active : integer range 0 to 3 := 0;
	
	signal player1_boost: std_logic_vector(3 downto 0) := "0000";
	signal player2_boost: std_logic_vector(3 downto 0) := "0000";
	
	constant boost_heigth : integer := 40;
	constant boost_length : integer := 40;
	
	--duration of the boost
	signal player1_boost_time : integer range 0 to 1000 := 0;
	signal player2_boost_time : integer range 0 to 1000 := 0;
	constant boost_duration : integer := 800;
	
	--generate the constant of the platform 1
	constant platform_1_length : integer := 400;
	constant platform_1_height : integer := 30;
	constant platform_1_pos_x : integer := 200;
	constant platform_1_pos_y : integer := 400;
	
	--generate the constant of the platform 2
	constant platform_2_length : integer := 200;
	constant platform_2_height : integer := 30;
	constant platform_2_pos_x : integer := 0;
	constant platform_2_pos_y : integer := 250;

	--generate the constant of the platform 3
	constant platform_3_length : integer := 200;
	constant platform_3_height : integer := 30;
	constant platform_3_pos_x : integer := 599;
	constant platform_3_pos_y : integer := 250;
	
	constant square_length : integer := 79;
	
	signal boost_x_random : integer range 0 to 759 := 0;
	signal boost_x_random_platform_1 : integer range 0 to 359 := 130;
	signal boost_x_random_platform_2 : integer range 0 to 159 := 80;
	signal boost_x_random_platform_3 : integer range 0 to 159 := 80;
	signal platform_random : integer range 0 to 3 := 0;
	signal incr : integer range 0 to 3 := 0;
	
	signal B1 , Y1, Sel1, Start1, UP1, DOWN1, L1, R1, A1, X1, LBT1, RBT1 : std_logic;
	signal B2 , Y2, Sel2, Start2, UP2, DOWN2, L2, R2, A2, X2, LBT2, RBT2 : std_logic;
	
begin

	 B1      <=    ctrl1(0);
    Y1      <=    ctrl1(1);
    Sel1    <=    ctrl1(2);
    Start1  <=    ctrl1(3);
    UP1     <=    ctrl1(4);
    DOWN1   <=    ctrl1(5);
    L1      <=    ctrl1(6);
    R1      <=    ctrl1(7);
    A1      <=    ctrl1(8);
    X1      <=    ctrl1(9);
    LBT1    <=    ctrl1(10);
    RBT1    <=    ctrl1(11);
	 
	 B2      <=    ctrl2(0);
    Y2      <=    ctrl2(1);
    Sel2    <=    ctrl2(2);
    Start2  <=    ctrl2(3);
    UP2     <=    ctrl2(4);
    DOWN2   <=    ctrl2(5);
    L2      <=    ctrl2(6);
    R2      <=    ctrl2(7);
    A2      <=    ctrl2(8);
    X2      <=    ctrl2(9);
    LBT2    <=    ctrl2(10);
    RBT2    <=    ctrl2(11);

process

begin

	wait until falling_edge(CLK_BOOST);
	
	if (game_state = 5 OR game_state = 6 OR game_state = 0) then
		boost_active <= "0000";
		boost_cooldown <= 0;
		player1_boost <= "0000";
		player2_boost <= "0000";
		
	elsif(game_state = 1) AND (boost_active = "0000") AND (player1_boost = "0000" 
	OR player2_boost = "0000") then
		
		if(boost_cooldown >= boost_max_cooldown) then
			
			--all the conditions are necessary to avoid that a boost pop under a player
			if(platform_random = 0) AND ((600 - boost_heigth - 1 > player1_y + square_length) OR (boost_x_random > player1_x + square_length) 
			OR (boost_x_random + boost_length < player1_x)) AND ((600 - boost_heigth - 1 > player2_y + square_length)
			OR (boost_x_random > player2_x + square_length) OR (boost_x_random + boost_length < player2_x)) then
			
				boost_x <= boost_x_random;
				boost_y <= 600 - boost_heigth - 1;
				boost_active(boost_select) <= '1';
				boost_cooldown <= 0;
				boost_select_active <= boost_select;
				
			elsif (platform_random = 1) AND ((platform_1_pos_y- boost_heigth - 1 > player1_y + square_length) 
			OR (platform_1_pos_y - 1 < player1_y) 
			OR (platform_1_pos_x  + boost_x_random_platform_1 > player1_x + square_length) 
			OR (platform_1_pos_x + boost_x_random_platform_1 + boost_length < player1_x)) 
			AND ((platform_1_pos_y - boost_heigth - 1 > player2_y + square_length) 
			OR (platform_1_pos_y - 1 < player2_y) 
			OR (platform_1_pos_x + boost_x_random_platform_1 > player2_x + square_length) 
			OR (platform_1_pos_x  + boost_x_random_platform_1 + boost_length < player2_x)) then
			
				boost_x <= platform_1_pos_x + boost_x_random_platform_1;
				boost_y <= platform_1_pos_y - boost_heigth - 1;
				boost_active(boost_select) <= '1';
				boost_cooldown <= 0;
				boost_select_active <= boost_select;
				
			elsif (platform_random = 2) AND ((platform_2_pos_y- boost_heigth - 1 > player1_y + square_length) 
			OR (platform_2_pos_y - 1 < player1_y) 
			OR (platform_2_pos_x  + boost_x_random_platform_2 > player1_x + square_length) 
			OR (platform_2_pos_x  + boost_x_random_platform_2 + boost_length < player1_x)) 
			AND ((platform_2_pos_y - boost_heigth - 1 > player2_y + square_length) 
			OR (platform_2_pos_y - 1 < player2_y) 
			OR (platform_2_pos_x  + boost_x_random_platform_2 > player2_x + square_length) 
			OR (platform_2_pos_x  + boost_x_random_platform_2 + boost_length < player2_x)) then
			
				boost_x <= platform_2_pos_x + boost_x_random_platform_2;
				boost_y <= platform_2_pos_y - boost_heigth - 1;
				boost_active(boost_select) <= '1';
				boost_cooldown <= 0;
				boost_select_active <= boost_select;
				
			elsif (platform_random = 3) AND ((platform_3_pos_y- boost_heigth - 1 > player1_y + square_length) 
			OR (platform_3_pos_y - 1 < player1_y) 
			OR (platform_3_pos_x + boost_x_random_platform_3 > player1_x + square_length) 
			OR (platform_3_pos_x + boost_x_random_platform_3 + boost_length < player1_x)) 
			AND ((platform_3_pos_y - boost_heigth - 1 > player2_y + square_length) 
			OR (platform_3_pos_y - 1 < player2_y) 
			OR (platform_3_pos_x + boost_x_random_platform_3 > player2_x + square_length) 
			OR (platform_3_pos_x + boost_x_random_platform_3 + boost_length < player2_x)) then
			
				boost_x <= platform_3_pos_x + boost_x_random_platform_3;
				boost_y <= platform_3_pos_y - boost_heigth - 1;
				boost_active(boost_select) <= '1';
				boost_cooldown <= 0;
				boost_select_active <= boost_select;
				
			end if;
		else
			boost_cooldown <= boost_cooldown + 1;
		end if;
	end if;
	
	if (boost_active /= "0000") then
		if (boost_y <= player1_y + square_length - 5) AND (boost_y >= player1_y - boost_heigth + 5)
		AND (boost_x <= player1_x + square_length - 5) AND (boost_x + boost_length >= player1_x + 5) then
			player1_boost <= "0000";
			player1_boost(boost_select_active) <= '1';
			boost_active <= "0000";
			player1_boost_time <= 0;
		elsif (boost_y <= player2_y + square_length - 5) AND (boost_y >= player2_y - boost_heigth + 5)
		AND (boost_x <= player2_x + square_length - 5) AND (boost_x + boost_length >= player2_x + 5) then
			player2_boost <= "0000";
			player2_boost(boost_select_active) <= '1';
			boost_active <= "0000";
			player2_boost_time <= 0;
		end if;
	end if;
	
	if (player1_boost /= "0000") then
		if(player1_boost_time = boost_duration) then
			player1_boost <= "0000";
		else
			player1_boost_time <= player1_boost_time + 1;
		end if;
	end if;
	
	if (player2_boost /= "0000") then
		if(player2_boost_time = boost_duration) then
			player2_boost <= "0000";
		else
			player2_boost_time <= player2_boost_time + 1;
		end if;
	end if;
	
	--generation of the randomization of the boost
	if (ctrl1 /= "000000000000") then
		boost_select <= boost_select + 1;
	end if;
	if (ctrl2 /= "000000000000") then
		platform_random <= platform_random + 1;
	end if;
	
	if(B1 = '1') OR (B2 = '1') OR (DOWN1 = '1') OR (RBT2 = '1') OR (L1 = '1')
	OR (R2 = '1') OR (Y1 = '1') then
		if(boost_max_cooldown > 500 - incr) then
			boost_max_cooldown <= 300;
		else
			boost_max_cooldown <= boost_max_cooldown + incr;
		end if;
		if(boost_x_random_platform_3 > 159 - incr) then
			boost_x_random_platform_3 <= 0;
		else
			boost_x_random_platform_3 <= boost_x_random_platform_3 + incr;
		end if;
		if(boost_x_random_platform_2 > 159 -incr) then
			boost_x_random_platform_2 <= 0;
		else
			boost_x_random_platform_2 <= boost_x_random_platform_2 + incr;
		end if;
		if(boost_x_random_platform_1 > 359 - incr) then
			boost_x_random_platform_1 <= 0;
		else
			boost_x_random_platform_1 <= boost_x_random_platform_1 + incr;
		end if;
		if(boost_x_random > 759 - incr) then
			boost_x_random <= 0;
		else
			boost_x_random <= boost_x_random + incr;
		end if;
		boost_select <= boost_select + 1;
		platform_random <= platform_random + 1;
	end if;
	
	incr <= incr + 1;
	
	
end process boost_arch;
--player1
player1_boost_output(0) <= player1_boost(0);
player1_boost_output(1) <= player1_boost(1);
player1_boost_output(2) <= player1_boost(2);
player1_boost_output(3) <= player2_boost(3);

--player2
player2_boost_output(0) <= player2_boost(0);
player2_boost_output(1) <= player2_boost(1);
player2_boost_output(2) <= player2_boost(2);
player2_boost_output(3) <= player1_boost(3);

end architecture boost_arch;