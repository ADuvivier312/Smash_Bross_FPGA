library ieee;
use ieee.std_logic_1164.ALL;
use ieee.std_logic_ARITH.ALL;
use ieee.std_logic_UNSIGNED.ALL;

entity player is port
	(
	
		CLK_player : in std_logic;
		ctrl 	: in std_logic_vector(11 downto 0) := "000000000000";
		player_nbr : in std_logic;
		
		other_player_x : in integer range 0 to 800;
		other_player_y : in integer range 0 to 600;
		game_state : in integer range 0 to 10;
		hit : in std_logic;
		boost : in std_logic_vector(3 downto 0);
		
		h_var : buffer integer range 0 to 800;
		v_var : buffer integer range 0 to 600;
		dash_cooldown : buffer integer range 0 to 100 := 0;
		other_player_life : buffer integer range 0 to 350 := 350;
		player_state : out std_logic_vector(4 downto 0) := "00000";
		shoot : out std_logic
	
	);
end player;

architecture player_arch of player is

	--flag of beginning, to initialise the buffer
	signal init : std_logic := '1';

	--initialisation of the positions
	--h_var <= 200;
	--v_var <= 533; -- 600 - square_length - 1
	
	--Flag to know the direction
	signal left_dir : std_logic := '0';
	signal down_dir : std_logic := '1';
	
	--Flag to tell if speed increase or not
	signal incr_speed : std_logic := '1';
	signal vert_enable : std_logic := '1';
	signal stop : std_logic := '0';
	signal jump_nbr : integer range 0 to 3 := 0;
	
	--Vertical and horizontal speed
	signal h_speed : integer range 0 to 30 := 3;
	signal v_speed : integer range 0 to 30 := 0;
	
	--Counter to slow down the variation of speed
	signal speed_count : std_logic_vector (5 downto 0) := "000000";
	
	--Counter to limit the Dash
	signal dash_counter : integer range 0 to 200 := 10;
	
	constant h_back_porch 	: integer := 64;
	constant h_active 		: integer := 800;
	constant h_front_porch 	: integer := 56;
	constant h_sync_length	: integer := 120;
	constant h_length		: integer := 1040;
	
	constant v_back_porch 	: integer := 23;
	constant v_active 		: integer := 600;
	constant v_front_porch	: integer := 37;
	constant v_sync_length	: integer := 6;
	constant v_length		: integer := 666;
	
	constant speed_var       : integer := 1;
	constant square_length   : integer := 79;
	signal initial_speed   : integer range 15 to 26 := 15;
	
	--different constant for the horizontal speed
	signal normal_h_speed : integer range 7 to 12 := 7;
	constant dash_h_speed : integer := 23;
	constant body_speed : integer := 20;
	signal go_down_speed : integer range 20 to 30 := 20;
	
	--to have a correct behaviour, the order of heigth must be 2, 3, 1
	--generate the constant of the platform 1
	constant platform_1_length : integer := 400;
	constant platform_1_height : integer := 30;
	constant platform_1_pos_x : integer := 200;
	constant platform_1_pos_y : integer := 400;
	
	--signal to update position of the platform to make it generic
	signal  plat_1_length_update : integer range 0 to 800 := 0;
	signal  plat_1_pos_x_update : integer range 0 to 800 := 0;
	
	--generate the constant of the platform 2
	constant platform_2_length : integer := 200;
	constant platform_2_height : integer := 30;
	constant platform_2_pos_x : integer := 0;
	constant platform_2_pos_y : integer := 250;
	
	--signal to update position of the platform to make it generic
	signal  plat_2_length_update : integer range 0 to 800 := 0;
	signal  plat_2_pos_x_update : integer range 0 to 800 := 0;

	--generate the constant of the platform 3
	constant platform_3_length : integer := 200;
	constant platform_3_height : integer := 30;
	constant platform_3_pos_x : integer := 599;
	constant platform_3_pos_y : integer := 250;
	
	--signal to update position of the platform to make it generic
	signal  plat_3_length_update : integer range 0 to 800 := 0;
	signal  plat_3_pos_x_update : integer range 0 to 800 := 0;

	--generate the dash cooldown bar
	constant bar_length : integer := 300;
	constant bar_height : integer := 20;
	constant bar_pos_x : integer := 15;
	constant bar_pos_y : integer := 15;
	
	--constant for the maximum of the displacement
	constant max_body_attack : integer := 3;
	constant max_dash_counter : integer := 10;
	
	--generate the constant of the damage
	signal dash_damage : integer range 0 to 30 := 15;
	signal body_damage : integer range 0 to 80 := 40;
	signal proj_damage : integer range 0 to 60 := 30;
	signal go_down_damage : integer range 20 to 40 := 40;

	signal B , Y, Sel, Start, UP, DOWN, L, R, A, X, LBT, RBT : std_logic;
	
	--Flag for the buttons
	signal B_flag: std_logic := '0';
	signal down_flag : std_logic := '0';
	
	--Flag for the player
	signal player_turn : std_logic := '0';
	
	--Game_state when we have win
	signal game_state_win : integer range 0 to 10 := 0;
	
	--Flag to tell that we have do an attack
	signal dash_flag : std_logic := '0';
	signal go_down_flag_attack : std_logic := '0';
	signal up_attack : std_logic := '0';
	signal lateral_attack : std_logic := '0';
	
	--Counter for the body to body attack
	signal body_cooldown : integer range 0 to 25 := 0;
	signal body_attack : integer range 0 to 10 := 4;
	
	--Counter for the shoot
	signal shoot_cooldown : integer range 0 to 25 := 0;

begin

	 B      <=    ctrl(0);
    Y      <=    ctrl(1);
    Sel    <=    ctrl(2);
    Start  <=    ctrl(3);
    UP     <=    ctrl(4);
    DOWN   <=    ctrl(5);
    L      <=    ctrl(6);
    R      <=    ctrl(7);
    A      <=    ctrl(8);
    X      <=    ctrl(9);
    LBT    <=    ctrl(10);
    RBT    <=    ctrl(11);

	player: process
	
   --limit of displacement for the player
	variable ground : integer range 0 to 600 := 600;
	variable previous_ground : integer range 0 to 600 := 600;
	variable left_limit : integer range 0 to 800 := 0;
	variable right_limit : integer range 0 to 800 := 800;
	variable upper_limit : integer range 0 to 600 := 0;
	
	--variable to have the real value of the horizontal position
	variable h_var_real : integer range 0 to 800 := 0;
	
	--signal to know what platform is below me
	variable plat_below_x : integer range 0 to 800 := 0;
	variable plat_below_y : integer range 0 to 600 := 0;
	
	--variable for the life of the other player
	variable other_player_life_var : integer range 0 to 350 := 350;
	
	begin
		wait until rising_edge(CLK_player);
		
			player_turn <= NOT player_turn;
			shoot <= '0';
			
			if (hit = '1') then
				if(other_player_life_var >= proj_damage) then
					other_player_life_var := other_player_life_var - proj_damage;
				else 
					other_player_life_var := 0;
				end if;
			end if;
		
			if (init = '0') AND (player_turn = player_nbr) AND ((game_state = 1) OR (game_state = game_state_win)) then
			
				h_var_real := h_var;
				
				--implementation of the possible boost of the player
				dash_damage <= 15;
				body_damage <= 40;
				proj_damage <= 30;
				go_down_damage <= 40;
				initial_speed <= 15;
				normal_h_speed <= 7;
				go_down_speed <= 20;
				
				if(boost(0) = '1') AND (boost(3) = '0') then
					body_damage <= 80;
				elsif(boost(0) = '1') AND (boost(3) = '1') then
					body_damage <= 40;
				elsif(boost(1) = '1') AND (boost(3) = '0') then
					proj_damage <= 60;
				elsif(boost(1) = '1') AND (boost(3) = '1') then
					proj_damage <= 30;
				elsif(boost(2) = '1') then
					initial_speed <= 26;
					normal_h_speed <= 12;
					go_down_speed <= 30;
				end if;
				
				if(boost(3) = '1') then
					if (boost(0) = '0') then
						body_damage <= 20;
					end if;
					if(boost(1) = '0') then
						proj_damage <= 15;
					end if;
					dash_damage <= 7;
					go_down_damage <= 20;
				end if;
				
				if(shoot_cooldown = 25) then
					if( A = '1') then
						shoot <= '1';
						shoot_cooldown <= 0;
					end if;
				else
					shoot_cooldown <= shoot_cooldown + 1;
				end if;
				
				--computation of the platform below me to compare with the other user
				if (v_var <= platform_2_pos_y - square_length - 1) AND (h_var >= plat_2_pos_x_update - square_length - 1)
				AND (h_var <= plat_2_pos_x_update + plat_2_length_update - 1) AND (down_flag = '0') then
					plat_below_x := plat_2_pos_x_update;
					plat_below_y := platform_2_pos_y;
					
				elsif (v_var <= platform_3_pos_y - square_length - 1) AND (h_var >= plat_3_pos_x_update - square_length - 1)
				AND (h_var <= plat_3_pos_x_update + plat_3_length_update - 1) AND (down_flag = '0') then
					plat_below_x := plat_3_pos_x_update;
					plat_below_y := platform_3_pos_y;
					
				elsif (v_var <= platform_1_pos_y - square_length - 1) AND (h_var >= plat_1_pos_x_update - square_length - 1)
				AND (h_var <= plat_1_pos_x_update + plat_1_length_update - 1) AND (down_flag = '0') then
					plat_below_x := plat_1_pos_x_update;
					plat_below_y := platform_1_pos_y;
					
				else
					plat_below_x := 800;
					plat_below_y := 600;
				end if;
				
					
				--computation of the location of the ground
				previous_ground := ground;
				if (h_var <= other_player_x + square_length) AND (h_var >= other_player_x - square_length)
				AND (v_var < other_player_y + square_length) AND (other_player_y <= plat_below_y) 
				AND (game_state /= game_state_win) then
					ground := other_player_y;
					if (v_speed = 0) then
						if (other_player_y /= previous_ground) then
							down_dir <= '1';
							incr_speed <= '1';
							vert_enable <= '1';
						end if;
					end if;
					
					
				elsif (plat_below_x = 800) AND (plat_below_y = 600) then
					ground := v_active;
					if (v_speed = 0) then
						if (previous_ground /= v_active) then
							down_dir <= '1';
							incr_speed <= '1';
							vert_enable <= '1';
						end if;
					end if;
					
				else
					if (down_flag = '0') then
						ground := plat_below_y;
						if (v_speed = 0) then
							if (previous_ground /= plat_below_y) AND (previous_ground /= v_active) then
								down_dir <= '1';
								incr_speed <= '1';
								vert_enable <= '1';
							end if;
						end if;
					else
						ground := v_active;
						if (v_speed = 0) then
							if (previous_ground /= v_active) then
								down_dir <= '1';
								incr_speed <= '1';
								vert_enable <= '1';
							end if;
						end if;
					end if;
					
				end if;
				
				--computation of the left limit
				if (v_var <= other_player_y + square_length) AND (v_var >= other_player_y - square_length)
				AND (h_var > other_player_x ) AND (game_state /= game_state_win) then
					left_limit := other_player_x + square_length + 1;
				else
					left_limit := 0;
				end if;
				
				--computation of the rigth limit
				if (v_var <= other_player_y + square_length) AND (v_var >= other_player_y - square_length)
				AND (h_var < other_player_x + square_length) AND (game_state /= game_state_win) then
					right_limit := other_player_x;
				else
					right_limit := h_active;
				end if;
				
				--computation of the upper limit
				if (h_var <= other_player_x + square_length) AND (h_var >= other_player_x - square_length)
				AND (v_var > other_player_y) AND (game_state /= game_state_win) then
					upper_limit := other_player_y + square_length + 1;
				else
					upper_limit := 0;
				end if;
				
				--horizontal displacement
				player_state(2) <= '0';
				if(dash_flag = '1') then
					dash_counter <= dash_counter + 1;
					if (left_dir = '0') AND (h_var <= right_limit - square_length - dash_h_speed - 1) then
						player_state(2) <= '1';
						h_var_real := h_var + dash_h_speed;
						
					elsif (left_dir = '1') AND (h_var >= left_limit + dash_h_speed) then
					   player_state(2) <= '1';
						h_var_real := h_var - dash_h_speed;
						
					elsif (h_var > right_limit - square_length - dash_h_speed - 1) then
						h_var_real := right_limit - square_length - 1;
						dash_counter <= max_dash_counter;
						dash_flag <= '0';
						if(right_limit = other_player_x) AND (dash_counter /= 0) then
							if(other_player_life_var >= dash_damage) then
								other_player_life_var := other_player_life_var - dash_damage;
							else 
								other_player_life_var := 0;
							end if;
						end if;
					elsif (h_var < left_limit + dash_h_speed) then
						h_var_real := left_limit;
						dash_counter <= max_dash_counter;
						dash_flag <= '0';
						if(left_limit = other_player_x + square_length + 1) AND (dash_counter /= 0) then
							if(other_player_life_var >= dash_damage) then
								other_player_life_var := other_player_life_var - dash_damage;
							else 
								other_player_life_var := 0;
							end if;
						end if;
					end if;
				
				elsif (lateral_attack = '1') then
					body_attack <= body_attack + 1;
					if (left_dir = '0') AND (h_var <= right_limit - square_length - body_speed - 1) then
						player_state(2) <= '1';
						h_var_real := h_var + body_speed;
						
					elsif (left_dir = '1') AND (h_var >= left_limit + body_speed) then
						player_state(2) <= '1';
						h_var_real := h_var - body_speed;
						
					elsif (h_var > right_limit - square_length - body_speed - 1) then
						h_var_real := right_limit - square_length - 1;
						body_attack <= max_body_attack;
						lateral_attack <= '0';
						if(right_limit = other_player_x)  then
							if(other_player_life_var >= body_damage) then
								other_player_life_var := other_player_life_var - body_damage;
							else 
								other_player_life_var := 0;
							end if;
						end if;
					elsif (h_var < left_limit + body_speed) then
						h_var_real := left_limit;
						body_attack <= max_body_attack;
						lateral_attack <= '0';
						if(left_limit = other_player_x + square_length + 1) then
							if(other_player_life_var >= body_damage) then
								other_player_life_var := other_player_life_var - body_damage;
							else 
								other_player_life_var := 0;
							end if;
						end if;
					end if;
						
				else
					if (R ='1') then
						if (h_var <= right_limit - square_length - normal_h_speed - 1) then
							h_var_real := h_var + normal_h_speed;
							left_dir <= '0';
							player_state(2) <= '1';
						else
							left_dir <= '0';
							h_var_real := right_limit - square_length - 1;
						end if;
					end if;
					
					if (L ='1') then
						if (h_var >= left_limit + normal_h_speed) then
							h_var_real := h_var - normal_h_speed;
							left_dir <= '1';
							player_state(2) <= '1';
						else
							left_dir <= '1';
							h_var_real := left_limit;
						end if;
					end if;
				end if;
				
				--avoid to enter into the other player by on of its corner
				if(other_player_x <= h_var_real + square_length) AND (other_player_x >= h_var_real) AND (game_state /= game_state_win) then
					if (down_dir = '1') AND (other_player_y <= v_var + square_length + v_speed) 
					AND (other_player_y > v_var) then
						ground := other_player_y;
					elsif (down_dir = '0') AND (other_player_y + square_length >= v_var - v_speed) 
					AND (other_player_y + square_length < v_var + square_length) then
						upper_limit := other_player_y + square_length + 1;
					end if;
				
				elsif (other_player_x + square_length >= h_var_real) AND (other_player_x + square_length <= h_var_real + square_length)
				AND (game_state /= game_state_win) then
					if (down_dir = '1') AND (other_player_y <= v_var + square_length + v_speed) 
					AND (other_player_y > v_var) then
						ground := other_player_y;
					elsif (down_dir = '0') AND (other_player_y + square_length >= v_var - v_speed) 
					AND (other_player_y + square_length < v_var + square_length) then
						upper_limit := other_player_y + square_length + 1;
					end if;
				
				end if;
				
				
				--gestion of the vertical displacements
				if (up_attack = '0') then
					if(vert_enable = '1') then
						player_state(1) <= '1';
						if (v_speed = 0) then 
							incr_speed <= '1';
							v_speed <= v_speed + 1;
							down_dir <= '1';
						elsif (incr_speed = '1') then
							v_speed <= v_speed + 1;
						else
							v_speed <= v_speed - 1;
						end if;
					end if;
				
					if (v_var <= upper_limit + v_speed - 1) then
						if(down_dir = '0') then
							down_dir <= '1';
							v_speed <= 0;
							v_var <= upper_limit;
						else
							v_var <= v_var + v_speed;
						end if;
					
					elsif (v_var >= ground - square_length - v_speed - 1) then
						if(down_dir = '1') then
							down_dir <= '0';
							v_speed <= 0;
							incr_speed <= '0';
							vert_enable <= '0';
							v_var <= ground - square_length - 1;
							go_down_flag_attack <= '0';
							player_state(1) <= '0';
							if (go_down_flag_attack = '1') AND (ground = other_player_y) then
								if(other_player_life_var >= go_down_damage) then
									other_player_life_var := other_player_life_var - go_down_damage;
								else 
									other_player_life_var := 0;
								end if;
							end if;
						else
							v_var <= v_var - v_speed;
						end if;
						if (v_speed = 0) then
							jump_nbr <= 0;
						end if;
					elsif (down_dir = '1') then
						v_var <= v_var + v_speed;
					else
						v_var <= v_var - v_speed;
					end if;
				
					--go down of the platform
					down_flag <= '0';
					if (DOWN = '1') then
						if ((ground /= other_player_y) OR (v_var < other_player_y - square_length - 1 - go_down_speed)) 
						AND (v_var + square_length + 1 < v_active - go_down_speed) then
							v_speed <= go_down_speed;
							down_dir <= '1';
							down_flag <= '1';
							ground := v_active;
							go_down_flag_attack <= '1';
							incr_speed <= '1';
							player_state(1) <= '1';
						end if;
					
					--check if the button to jump is press
					elsif (B = '1') AND (B_flag = '0') AND (jump_nbr /= 2) then
						B_flag <= '1';
						jump_nbr <= jump_nbr + 1;
						vert_enable <= '1';
						incr_speed <= '0';
						v_speed <= initial_speed;
						down_dir <= '0';
						--forget that we have dashed down
						go_down_flag_attack <= '0';
					end if;

					if (B = '0') then
						B_flag <= '0';
					end if;
				else
					body_attack <= body_attack + 1;
				
					if (v_var <= upper_limit + body_speed - 1) then
						down_dir <= '1';
						v_speed <= 0;
						v_var <= upper_limit;
						body_attack <= max_body_attack;
						up_attack <= '0';
						if(upper_limit = other_player_y + square_length + 1) then
							if(other_player_life_var >= body_damage) then
								other_player_life_var := other_player_life_var - body_damage;
							else 
								other_player_life_var := 0;
							end if;
						end if;
					else
						v_var <= v_var - body_speed;
					end if;
				end if;
				
				--implementation of the dash
				if (dash_cooldown = 100) then
					if (RBT = '1') AND (lateral_attack = '0') then
						dash_cooldown <= 0;
						dash_counter <= 0;
						dash_flag <= '1';
					end if;
				else
					dash_cooldown <= dash_cooldown + 1;
				end if;
				
				--reset of the flag of the dash
				if (dash_counter = max_dash_counter - 1) then
				dash_flag <= '0';
				end if;
				
				--implementation of the body attack
				if(body_cooldown = 25) then
					if (X = '1') then
						body_cooldown <= 0;
						body_attack <= 0;
						up_attack <= '1';
						down_dir <= '0';
						incr_speed <= '0';
						v_speed <= 5;
						vert_enable <= '1';
						go_down_flag_attack <= '0';
					elsif ( Y = '1') AND (dash_flag = '0') then
						body_cooldown <= 0;
						body_attack <= 0;
						lateral_attack <= '1';
						if(dash_cooldown = 100) then
							dash_cooldown <= 100;
						end if;
						dash_counter <= max_dash_counter;
						dash_flag <= '0';
					end if;
				else
					body_cooldown <= body_cooldown + 1;
				end if;
				
				--reset the flags of the attack
				if (body_attack = max_body_attack - 1) then
					lateral_attack <= '0';
					up_attack <= '0';
				end if;
			
			elsif(init = '1') then
				init <= '0';
				if (player_nbr = '0') then
					h_var_real := 200;
					v_var <= ground - square_length - 1;
					game_state_win <= 4;
					left_dir <= '0';
				else
					h_var_real := 500;
					v_var <= ground - square_length - 1;
					game_state_win <= 3;
					left_dir <= '1';
				end if;
				other_player_life_var := 350;
				
				--update of parameter for platform 1
				if ( platform_1_pos_x <= square_length - 1) then
					plat_1_pos_x_update <= square_length - 1;
					plat_1_length_update <= platform_1_length - (square_length - 1 - platform_1_pos_x);
				else
					plat_1_pos_x_update <= platform_1_pos_x;
					plat_1_length_update <= platform_1_length;
				end if;
				
				--update of parameter for platform 2
				if ( platform_2_pos_x <= square_length - 1) then
					plat_2_pos_x_update <= square_length - 1;
					plat_2_length_update <= platform_2_length - (square_length - 1 - platform_2_pos_x);
				else
					plat_2_pos_x_update <= platform_2_pos_x;
					plat_2_length_update <= platform_2_length;
				end if;
				
				--update of parameter for platform 3
				if ( platform_3_pos_x <= square_length - 1) then
					plat_3_pos_x_update <= square_length - 1;
					plat_3_length_update <= platform_3_length - (square_length - 1 - platform_3_pos_x);
				else
					plat_3_pos_x_update <= platform_3_pos_x;
					plat_3_length_update <= platform_3_length;
				end if;
				
			end if;
				
			if (game_state = 5 OR game_state = 6) then
				ground := 600;
				left_limit := 0;
				right_limit := 800;
				upper_limit := 0;
				dash_cooldown <= 0;
				body_cooldown <= 0;
				other_player_life_var := 350;
				if (player_nbr = '0') then
					h_var_real := 200;
					v_var <= ground - square_length - 1;
					left_dir <= '0';
				else
					h_var_real := 500;
					v_var <= ground - square_length - 1;
					left_dir <= '1';
				end if;
			end if;
			
			h_var <= h_var_real;
			other_player_life <= other_player_life_var;
			player_state(0) <= left_dir;
				
	end process player;
	
end player_arch;