library ieee;
use ieee.std_logic_1164.ALL;
use ieee.std_logic_ARITH.ALL;
use ieee.std_logic_UNSIGNED.ALL;

entity game_state is port
	(
		ctrl1 	: in std_logic_vector(11 downto 0) := "000000000000";
		ctrl2 	: in std_logic_vector(11 downto 0) := "000000000000";
		CLK    : in std_logic;
		
		life_player_1 : in integer range 0 to 350;
		life_player_2 : in integer range 0 to 350;
		
		game_state  : buffer integer range 0 to 10
	
	);
end game_state;

architecture game_state_arch of game_state is
	
	signal game_state_sig :integer range 0 to 10 := 0;

	signal B1 , Y1, Sel1, Start1, UP1, DOWN1, L1, R1, A1, X1, LBT1, RBT1 : std_logic;
	signal B2 , Y2, Sel2, Start2, UP2, DOWN2, L2, R2, A2, X2, LBT2, RBT2 : std_logic;
	
	--signal for the press of the start buttons
	signal Start1_press : std_logic := '0';
	signal Start2_press : std_logic := '0';

begin

	 B1      <=    ctrl1(0);
    Y1      <=    ctrl1(1);
    Sel1    <=    ctrl1(2);
    Start1  <=    ctrl1(3);
    UP1     <=    ctrl1(4);
    DOWN1   <=    ctrl1(5);
    L1      <=    ctrl1(6);
    R1      <=    ctrl1(7);
    A1      <=    ctrl1(8);
    X1      <=    ctrl1(9);
    LBT1    <=    ctrl1(10);
    RBT1    <=    ctrl1(11);
	 
	 B2      <=    ctrl2(0);
    Y2      <=    ctrl2(1);
    Sel2    <=    ctrl2(2);
    Start2  <=    ctrl2(3);
    UP2     <=    ctrl2(4);
    DOWN2   <=    ctrl2(5);
    L2      <=    ctrl2(6);
    R2      <=    ctrl2(7);
    A2      <=    ctrl2(8);
    X2      <=    ctrl2(9);
    LBT2    <=    ctrl2(10);
    RBT2    <=    ctrl2(11);
	 
	game_state <= game_state_sig;

	game_state_process : process
	begin
		wait until falling_edge(CLK);
		
		if(((X1 = '1') OR (X2 = '1')) AND (game_state_sig = 2)) then
			game_state_sig <= 6;
		end if;
		
		if(game_state_sig = 6) then
			game_state_sig <= 1;
		end if;
		
		if (Start1 = '1') AND (Start1_press = '0') then
			Start1_press <= '1';
			if (game_state_sig = 1) then 
				game_state_sig <= 2;
			elsif (game_state_sig = 3) OR (game_state_sig = 4) then
				game_state_sig <= 5;
			else
				game_state_sig <= 1;	
			end if;
		elsif (Start1 = '0') then
			Start1_press <= '0';
		end if;
		
		if (Start2 = '1') AND (Start2_press = '0') then
			Start2_press <= '1';
			if (game_state_sig = 1) then 
				game_state_sig <= 2;
			elsif (game_state_sig = 3) OR (game_state_sig = 4) then
				game_state_sig <= 5;
			else
				game_state_sig <= 1;	
			end if;
		elsif (Start2 = '0') then
			Start2_press <= '0';
		end if;
		
		if (life_player_1 = 0) AND (game_state_sig = 1) then
			game_state_sig <= 3;
		end if;
		
		if (life_player_2 = 0) AND (game_state_sig = 1) then
			game_state_sig <= 4;
		end if;
		
	end process game_state_process;
end game_state_arch;