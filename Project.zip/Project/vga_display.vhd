library ieee;
use ieee.std_logic_1164.ALL;
use ieee.std_logic_ARITH.ALL;
use ieee.std_logic_UNSIGNED.ALL;
use work.ALL;

entity vga_display is port 
	(
		CLK_50 : in std_logic;	
		RED: out std_logic_vector(3 downto 0);
		GREEN: out std_logic_vector(3 downto 0);  
		BLUE: out std_logic_vector(3 downto 0); 			
		SYNC: out std_logic_vector(1 downto 0);
		
		player1_state : in std_logic_vector(4 downto 0);
		player2_state : in std_logic_vector(4 downto 0);
		
		dash_cooldown_1 : in integer range 0 to 150;
		dash_cooldown_2 : in integer range 0 to 150;
		
		life_1 : in integer range 0 to 350;
		life_2 : in integer range 0 to 350;
		
		h_var_1 : in integer range 0 to 800;
		v_var_1 : in integer range 0 to 600;
		
		h_var_2 : in integer range 0 to 800;
		v_var_2 : in integer range 0 to 600;
		
		game_state : in integer range 0 to 10;
		
		X1_1, Y1_1, X2_1, Y2_1, X1_2, Y1_2, X2_2, Y2_2 : in integer range 0 to 800;
		
		dir1_1, dir1_2, dir2_1, dir2_2 : in std_logic;
		
		has_shoot1_1, has_shoot2_1, has_shoot1_2, has_shoot2_2 : in std_logic;
		
		player1_boost : in std_logic_vector(3 downto 0);
		player2_boost : in std_logic_vector(3 downto 0);
		boost_x_pos : in integer range 0 to 800;
		boost_y_pos : in integer range 0 to 600;
		
		boost_active : in std_logic_vector(3 downto 0)
		
	);
end entity vga_display;

architecture vga_display_arch of vga_display is

	--signals for the printing of player 1
	signal a_player1 : std_logic_vector(10 downto 0) := "00000000000";
	signal c_player1 : std_logic_vector(11 downto 0) := (others => '0');
	
	signal a_player1_iddle : std_logic_vector(10 downto 0) := "00000000000";
	signal c_player1_iddle : std_logic_vector(11 downto 0) := (others => '0');
	
	signal a_player1_jump : std_logic_vector(10 downto 0) := "00000000000";
	signal c_player1_jump : std_logic_vector(11 downto 0) := (others => '0');
	
	signal addr_cnt_1 : integer range 0 to 40 := 0;
	
	--signals for the printing of player 2
	signal a_player2 : std_logic_vector(10 downto 0) := "00000000000";
	signal c_player2 : std_logic_vector(11 downto 0) := (others => '0');
	
	signal a_player2_iddle : std_logic_vector(10 downto 0) := "00000000000";
	signal c_player2_iddle : std_logic_vector(11 downto 0) := (others => '0');
	
	signal a_player2_jump : std_logic_vector(10 downto 0) := "00000000000";
	signal c_player2_jump : std_logic_vector(11 downto 0) := (others => '0');
	
	signal addr_cnt_2 : integer range 0 to 40 := 0;
	
	--signals for the printing of the projectiles
	signal a_prj1_1 : std_logic_vector(8 downto 0) := "000000000";
	signal c_prj1_1 : std_logic_vector(11 downto 0) := (others => '0');
	
	signal a_prj1_2 : std_logic_vector(8 downto 0) := "000000000";
	signal c_prj1_2 : std_logic_vector(11 downto 0) := (others => '0');
	
	signal a_prj2_1 : std_logic_vector(8 downto 0) := "000000000";
	signal c_prj2_1 : std_logic_vector(11 downto 0) := (others => '0');
	
	signal a_prj2_2 : std_logic_vector(8 downto 0) := "000000000";
	signal c_prj2_2 : std_logic_vector(11 downto 0) := (others => '0');
	
	signal addr_cnt_p1_1 : integer range 0 to 30 := 0;
	signal addr_cnt_p1_2 : integer range 0 to 30 := 0;
	signal addr_cnt_p2_1 : integer range 0 to 30 := 0;
	signal addr_cnt_p2_2 : integer range 0 to 30 := 0;
	
	--signals to have a correct display
	signal player1_state_display : std_logic_vector(4 downto 0) := "00000";
	signal player2_state_display : std_logic_vector(4 downto 0) := "00000";
	
	signal h_var_1_display : integer range 0 to 800 := 200;
	signal v_var_1_display : integer range 0 to 600 := 533;
	signal h_var_2_display : integer range 0 to 800 := 200;
	signal v_var_2_display : integer range 0 to 600 := 533;
	signal game_state_display : integer range 0 to 10 := 0;
	
	signal dash_cooldown_1_display : integer range 0 to 150 := 0;
	signal dash_cooldown_2_display : integer range 0 to 150 := 0;
	
	signal life_1_display : integer range 0 to 350 := 350;
	signal life_2_display : integer range 0 to 350 := 350;
	
	signal X1_1_display, Y1_1_display, X2_1_display, Y2_1_display : integer range 0 to 800;
	signal X1_2_display, Y1_2_display, X2_2_display, Y2_2_display : integer range 0 to 800;
	
	--signal for the walk of player 1
	signal walk_cnt_1 : integer range 0 to 7 := 0;
	constant walk_cst_1 : integer := 4;
	
	--signal for the walk of player 2
	signal walk_cnt_2 : integer range 0 to 7 := 0;
	constant walk_cst_2 : integer := 4;
	
	--signals to double pikachu size
	signal double_line_pika : std_logic := '0';
	signal double_column_pika : std_logic := '0';
	
	--signals to double salameche size
	signal double_line_sala : std_logic := '0';
	signal double_column_sala : std_logic := '0';
	
	--Sync Signals
	signal h_sync : std_logic;
	signal v_sync : std_logic;
	
	--Video Enables
	signal video_en : std_logic;
	signal horizontal_en : std_logic;
	signal vertical_en : std_logic;
	
	--Color Signals
	signal color : std_logic_vector(11 downto 0) := (others => '0');
	
	--Sync Counters
	signal h_cnt : std_logic_vector(10 downto 0) := (others => '0');
	signal v_cnt : std_logic_vector (10 downto 0) := (others => '0');
	
	constant h_back_porch 	: integer := 64;
	constant h_active 		: integer := 800;
	constant h_front_porch 	: integer := 56;
	constant h_sync_length	: integer := 120;
	constant h_length		: integer := 1040;
	
	constant v_back_porch 	: integer := 23;
	constant v_active 		: integer := 600;
	constant v_front_porch	: integer := 37;
	constant v_sync_length	: integer := 6;
	constant v_length		: integer := 666;
	
	constant square_length   : integer := 79;
	constant sprite_size     : integer := 39;
	
	--generate the constant of the platform 1
	constant platform_1_length : integer := 400;
	constant platform_1_height : integer := 30;
	constant platform_1_pos_x : integer := 200;
	constant platform_1_pos_y : integer := 400;
	
	--generate the constant of the platform 2
	constant platform_2_length : integer := 200;
	constant platform_2_height : integer := 30;
	constant platform_2_pos_x : integer := 0;
	constant platform_2_pos_y : integer := 250;

	--generate the constant of the platform 3
	constant platform_3_length : integer := 200;
	constant platform_3_height : integer := 30;
	constant platform_3_pos_x : integer := 599;
	constant platform_3_pos_y : integer := 250;

	--generate the dash cooldown bar 1
	constant bar_1_length : integer := 300;
	constant bar_1_height : integer := 20;
	constant bar_1_pos_x : integer := 15;
	constant bar_1_pos_y : integer := 40;
	
	--generate the dash cooldown bar 2
	constant bar_2_length : integer := 300;
	constant bar_2_height : integer := 20;
	constant bar_2_pos_x : integer := 484;
	constant bar_2_pos_y : integer := 40;
	
	--generate the life bar 1
	constant life_1_length : integer := 350;
	constant life_1_height : integer := 20;
	constant life_1_pos_x : integer := 15;
	constant life_1_pos_y : integer := 15;
	
	--generate the life bar 2
	constant life_2_length : integer := 350;
	constant life_2_height : integer := 20;
	constant life_2_pos_x : integer := 434;
	constant life_2_pos_y : integer := 15;
	
	constant proj_double_length   : integer := 59;
	constant proj_length : integer := 29;
	constant proj_heigth : integer := 14;
	
	--signal for the animation of projectiles
	signal prj_cnt_1 : integer range 0 to 7 := 0;
	signal prj_cnt_2 : integer range 0 to 7 := 0;
	constant prj_cst : integer := 3;
	
	--constant for the boost
	constant boost_heigth : integer := 40;
	constant boost_length : integer := 40;
	
	constant player1_boost_pos_y : integer := 40;
	constant player1_boost_pos_x : integer := 335;
	
	constant player2_boost_pos_y : integer := 40;
	constant player2_boost_pos_x : integer := 424;

begin		
	ROM_player1 : entity work.player1
	port map(	address => a_player1,
					clock => CLK_50,
					q => c_player1
				);
				
	ROM_player1_iddle : entity work.player1_iddle
	port map(	address => a_player1_iddle,
					clock => CLK_50,
					q => c_player1_iddle
				);
				
	ROM_player1_jump : entity work.player1_jump
	port map(	address => a_player1_jump,
					clock => CLK_50,
					q => c_player1_jump
				);
				
	ROM_player2 : entity work.player2
	port map(	address => a_player2,
					clock => CLK_50,
					q => c_player2
				);
				
	ROM_player2_iddle : entity work.player2_iddle
	port map(	address => a_player2_iddle,
					clock => CLK_50,
					q => c_player2_iddle
				);
				
	ROM_player2_jump : entity work.player2_jump
	port map(	address => a_player2_jump,
					clock => CLK_50,
					q => c_player2_jump
				);
				
	ROM_proj1_1 : entity work.proj1_1
	port map(	address => a_prj1_1,
					clock => CLK_50,
					q => c_prj1_1
				);
				
	ROM_proj1_2 : entity work.proj1_2
	port map(	address => a_prj1_2,
					clock => CLK_50,
					q => c_prj1_2
				);
				
	ROM_proj2_1 : entity work.proj2_1
	port map(	address => a_prj2_1,
					clock => CLK_50,
					q => c_prj2_1
				);	
				
	ROM_proj2_2 : entity work.proj2_2
	port map(	address => a_prj2_2,
					clock => CLK_50,
					q => c_prj2_2
				);

video_en <= horizontal_en AND vertical_en;

process

begin

	wait until rising_edge(CLK_50);
		
		color <= "000000000000"; -- background color

		--Generate background
		if ( (v_cnt >= v_back_porch) AND (v_cnt <= v_back_porch + v_active)
			AND (h_cnt >= h_back_porch) AND (h_cnt <= h_back_porch + h_active)) then
			color <= "111111111111"; -- square color
		end if;
		
		--Generate projectile 1 player 1--
		if(has_shoot1_1 = '1') then
			if ( (v_cnt >= v_back_porch + Y1_1_display) AND (v_cnt <= v_back_porch + Y1_1_display + proj_heigth)
				AND (h_cnt >= h_back_porch + X1_1_display) AND (h_cnt <= h_back_porch + X1_1_display + proj_length)) then
				if (prj_cnt_1 >= prj_cst) then
					if (NOT (c_prj2_1 = "000011110000")) then
						color <= c_prj2_1;
					end if;
					if (dir1_1 = '1') then
						a_prj2_1 <= a_prj2_1 + 1;
					else 
						addr_cnt_p1_1 <= addr_cnt_p1_1 + 1;
						if ( addr_cnt_p1_1 = proj_length ) then
							addr_cnt_p1_1 <= 0;
							a_prj2_1 <= a_prj2_1 + proj_double_length ;					
						else
							a_prj2_1 <= a_prj2_1 - 1;
						end if;
					end if;
				else
					if (NOT (c_prj2_2 = "000011110000")) then
						color <= c_prj2_2;
					end if;
					if (dir1_1 = '1') then
						a_prj2_2 <= a_prj2_2 + 1;								
					else 
						addr_cnt_p1_1 <= addr_cnt_p1_1 + 1;
						if ( addr_cnt_p1_1 = proj_length ) then
							addr_cnt_p1_1 <= 0;
							a_prj2_2 <= a_prj2_2 + proj_double_length ;					
						else
							a_prj2_2 <= a_prj2_2 - 1;
						end if;
					end if;
				end if;
			end if;
		end if;
		
		--Generate projectile 2 player 1--
		if(has_shoot2_1 = '1') then
			if ( (v_cnt >= v_back_porch + Y2_1_display) AND (v_cnt <= v_back_porch + Y2_1_display + proj_heigth)
				AND (h_cnt >= h_back_porch + X2_1_display) AND (h_cnt <= h_back_porch + X2_1_display + proj_length)) then
				if (prj_cnt_1 < prj_cst) then
					if (NOT (c_prj2_1 = "000011110000")) then
						color <= c_prj2_1;
					end if;
					if (dir1_2 = '1') then
						a_prj2_1 <= a_prj2_1 + 1;
					else 
						addr_cnt_p1_2 <= addr_cnt_p1_2 + 1;
						if ( addr_cnt_p1_2 = proj_length ) then
							addr_cnt_p1_2 <= 0;
							a_prj2_1 <= a_prj2_1 + proj_double_length ;					
						else
							a_prj2_1 <= a_prj2_1 - 1;
						end if;
					end if;
				else
					if (NOT (c_prj2_2 = "000011110000")) then
						color <= c_prj2_2;
					end if;
					if (dir1_2 = '1') then
						a_prj2_2 <= a_prj2_2 + 1;								
					else 
						addr_cnt_p1_2 <= addr_cnt_p1_2 + 1;
						if ( addr_cnt_p1_2 = proj_length ) then
							addr_cnt_p1_2 <= 0;
							a_prj2_2 <= a_prj2_2 + proj_double_length ;					
						else
							a_prj2_2 <= a_prj2_2 - 1;
						end if;
					end if;
				end if;
			end if;
		end if;
		
		--Generate projectile 1 player 2--
		if(has_shoot1_2 = '1') then
			if ( (v_cnt >= v_back_porch + Y1_2_display) AND (v_cnt <= v_back_porch + Y1_2_display + proj_heigth)
				AND (h_cnt >= h_back_porch + X1_2_display) AND (h_cnt <= h_back_porch + X1_2_display + proj_length)) then
				if (prj_cnt_2 >= prj_cst) then
					if (NOT (c_prj1_1 = "000011110000")) then
						color <= c_prj1_1;
					end if;
					if (dir2_1 = '1') then
						a_prj1_1 <= a_prj1_1 + 1;
					else 
						addr_cnt_p2_1 <= addr_cnt_p2_1 + 1;
						if ( addr_cnt_p2_1 = proj_length ) then
							addr_cnt_p2_1 <= 0;
							a_prj1_1 <= a_prj1_1 + proj_double_length ;					
						else
							a_prj1_1 <= a_prj1_1 - 1;
						end if;
					end if;
				else
					if (NOT (c_prj1_2 = "000011110000")) then
						color <= c_prj1_2;
					end if;
					if (dir2_1 = '1') then
						a_prj1_2 <= a_prj1_2 + 1;								
					else 
						addr_cnt_p2_1 <= addr_cnt_p2_1 + 1;
						if ( addr_cnt_p2_1 = proj_length ) then
							addr_cnt_p2_1 <= 0;
							a_prj1_2 <= a_prj1_2 + proj_double_length ;					
						else
							a_prj1_2 <= a_prj1_2 - 1;
						end if;
					end if;
				end if;
			end if;
		end if;
		
		--Generate projectile 2 player 2--
		if(has_shoot2_2 = '1') then
			if ( (v_cnt >= v_back_porch + Y2_2_display) AND (v_cnt <= v_back_porch + Y2_2_display + proj_heigth)
				AND (h_cnt >= h_back_porch + X2_2_display) AND (h_cnt <= h_back_porch + X2_2_display + proj_length)) then
				if (prj_cnt_2 < prj_cst) then
					if (NOT (c_prj1_1 = "000011110000")) then
						color <= c_prj1_1;
					end if;
					if (dir2_2 = '1') then
						a_prj1_1 <= a_prj1_1 + 1;
					else 
						addr_cnt_p2_2 <= addr_cnt_p2_2 + 1;
						if ( addr_cnt_p2_2 = proj_length ) then
							addr_cnt_p2_2 <= 0;
							a_prj1_1 <= a_prj1_1 + proj_double_length ;					
						else
							a_prj1_1 <= a_prj1_1 - 1;
						end if;
					end if;
				else
					if (NOT (c_prj1_2 = "000011110000")) then
						color <= c_prj1_2;
					end if;
					if (dir2_2 = '1') then
						a_prj1_2 <= a_prj1_2 + 1;								
					else 
						addr_cnt_p2_2 <= addr_cnt_p2_2 + 1;
						if ( addr_cnt_p2_2 = proj_length ) then
							addr_cnt_p2_2 <= 0;
							a_prj1_2 <= a_prj1_2 + proj_double_length ;					
						else
							a_prj1_2 <= a_prj1_2 - 1;
						end if;
					end if;
				end if;
			end if;
		end if;
		
		if (game_state_display /= 0) then
			--Generate platform 1
			if ( (v_cnt >= v_back_porch + platform_1_pos_y) AND (v_cnt <= v_back_porch + platform_1_pos_y + platform_1_height)
				AND (h_cnt >= h_back_porch + platform_1_pos_x) AND (h_cnt <= h_back_porch + platform_1_pos_x + platform_1_length)) then
				color <= "010110011101"; -- square color
			end if;
			
			--Generate platform 2
			if ( (v_cnt >= v_back_porch + platform_2_pos_y) AND (v_cnt <= v_back_porch + platform_2_pos_y + platform_2_height)
				AND (h_cnt >= h_back_porch + platform_2_pos_x) AND (h_cnt <= h_back_porch + platform_2_pos_x + platform_2_length)) then
				color <= "110101011101"; -- square color
			end if;
			
			--Generate platform 1
			if ( (v_cnt >= v_back_porch + platform_3_pos_y) AND (v_cnt <= v_back_porch + platform_3_pos_y + platform_3_height)
				AND (h_cnt >= h_back_porch + platform_3_pos_x) AND (h_cnt <= h_back_porch + platform_3_pos_x + platform_3_length)) then
				color <= "100010001000"; -- square color
			end if;
			
			if(game_state_display /= 2) AND (game_state_display /= 5) then
				-- generate player 1
				if ( (v_cnt >= v_back_porch + v_var_1_display) AND (v_cnt <= v_back_porch + square_length + v_var_1_display)
					AND (h_cnt >= h_back_porch + h_var_1_display) AND (h_cnt <= h_back_porch + square_length + h_var_1_display) AND (game_state_display /= 3)) then
					
					if(player1_state_display(1) = '0') then
						if (walk_cnt_1 >= walk_cst_1) then
							if (player1_state_display(0) = '1') then
								if (NOT (c_player1_iddle = "000011110000")) then
									color <= c_player1_iddle;
								end if;
								double_line_pika <= NOT double_line_pika;
								if(double_line_pika = '1') then
									a_player1_iddle <= a_player1_iddle + 1;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_1_display) then
									double_column_pika <= NOT double_column_pika;
									if(double_column_pika = '0') then
										a_player1_iddle <= a_player1_iddle - sprite_size;
									end if;
								end if;
							else 
								if (NOT (c_player1_iddle = "000011110000")) then
									color <= c_player1_iddle;
								end if;
								double_line_pika <= NOT double_line_pika;
								if(double_line_pika = '1') then
									addr_cnt_1 <= addr_cnt_1 + 1;
									if ( addr_cnt_1 = sprite_size ) then
										addr_cnt_1 <= 0;
										a_player1_iddle <= a_player1_iddle + square_length;					
									else
										a_player1_iddle <= a_player1_iddle - 1;
									end if;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_1_display) then
									double_column_pika <= NOT double_column_pika;
									if(double_column_pika = '0') then
										a_player1_iddle <= a_player1_iddle + sprite_size;
									end if;
								end if;
							end if;
						else
							if (player1_state_display(0) = '1') then
								if (NOT (c_player1 = "000011110000")) then
									color <= c_player1;
								end if;
								double_line_pika <= NOT double_line_pika;
								if(double_line_pika = '1') then
									a_player1 <= a_player1 + 1;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_1_display) then
									double_column_pika <= NOT double_column_pika;
									if(double_column_pika = '0') then
										a_player1 <= a_player1- sprite_size;
									end if;
								end if;
							else 
								if (NOT (c_player1 = "000011110000")) then
									color <= c_player1;
								end if;
								double_line_pika <= NOT double_line_pika;
								if(double_line_pika = '1') then
									addr_cnt_1 <= addr_cnt_1 + 1;
									if ( addr_cnt_1 = sprite_size ) then
										addr_cnt_1 <= 0;
										a_player1 <= a_player1 + square_length;					
									else
										a_player1 <= a_player1 - 1;
									end if;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_1_display) then
									double_column_pika <= NOT double_column_pika;
									if(double_column_pika = '0') then
										a_player1 <= a_player1 + sprite_size;
									end if;
								end if;
							end if;
						end if;
					else
						if (player1_state_display(0) = '1') then
							if (NOT (c_player1_jump = "000011110000")) then
								color <= c_player1_jump;
							end if;
							double_line_pika <= NOT double_line_pika;
							if(double_line_pika = '1') then
								a_player1_jump <= a_player1_jump + 1;
							end if;
							if(h_cnt = h_back_porch + square_length + h_var_1_display) then
								double_column_pika <= NOT double_column_pika;
								if(double_column_pika = '0') then
									a_player1_jump <= a_player1_jump - sprite_size;
								end if;
							end if;
						else 
							if (NOT (c_player1_jump = "000011110000")) then
								color <= c_player1_jump;
							end if;
							double_line_pika <= NOT double_line_pika;
							if(double_line_pika = '1') then
								addr_cnt_1 <= addr_cnt_1 + 1;
								if ( addr_cnt_1 = sprite_size ) then
									addr_cnt_1 <= 0;
									a_player1_jump <= a_player1_jump + square_length;					
								else
									a_player1_jump <= a_player1_jump - 1;
								end if;
							end if;
							if(h_cnt = h_back_porch + square_length + h_var_1_display) then
								double_column_pika <= NOT double_column_pika;
								if(double_column_pika = '0') then
									a_player1_jump <= a_player1_jump + sprite_size;
								end if;
							end if;
						end if;
					end if;
				end if;
				
				--generate player 2
				if ( (v_cnt >= v_back_porch + v_var_2_display) AND (v_cnt <= v_back_porch + square_length + v_var_2_display)
					AND (h_cnt >= h_back_porch + h_var_2_display) AND (h_cnt <= h_back_porch + square_length + h_var_2_display) AND (game_state_display /= 4)) then
					if(player2_state_display(1) = '0') then
						if (walk_cnt_2 >= walk_cst_2) then
							if (player2_state_display(0) = '1') then
								if (NOT (c_player2_iddle = "000011110000")) then
									color <= c_player2_iddle;
								end if;
								double_line_sala <= NOT double_line_sala;
								if(double_line_sala = '1') then
									a_player2_iddle <= a_player2_iddle + 1;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_2_display) then
									double_column_sala <= NOT double_column_sala;
									if(double_column_sala = '0') then
										a_player2_iddle <= a_player2_iddle - sprite_size;
									end if;
								end if;
							else 
								if (NOT (c_player2_iddle = "000011110000")) then
									color <= c_player2_iddle;
								end if;
								double_line_sala <= NOT double_line_sala;
								if(double_line_sala = '1') then
									addr_cnt_2 <= addr_cnt_2 + 1;
									if ( addr_cnt_2 = sprite_size ) then
										addr_cnt_2 <= 0;
										a_player2_iddle <= a_player2_iddle + square_length;					
									else
										a_player2_iddle <= a_player2_iddle - 1;
									end if;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_2_display) then
									double_column_sala <= NOT double_column_sala;
									if(double_column_sala = '0') then
										a_player2_iddle <= a_player2_iddle + sprite_size;
									end if;
								end if;
							end if;
						else
							if (player2_state_display(0) = '1') then
								if (NOT (c_player2 = "000011110000")) then
									color <= c_player2;
								end if;
								double_line_sala <= NOT double_line_sala;
								if(double_line_sala = '1') then
									a_player2 <= a_player2 + 1;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_2_display) then
									double_column_sala <= NOT double_column_sala;
									if(double_column_sala = '0') then
										a_player2 <= a_player2 - sprite_size;
									end if;
								end if;
							else 
								if (NOT (c_player2 = "000011110000")) then
									color <= c_player2;
								end if;
								double_line_sala <= NOT double_line_sala;
								if(double_line_sala = '1') then
									addr_cnt_2 <= addr_cnt_2 + 1;
									if ( addr_cnt_2 = sprite_size ) then
										addr_cnt_2 <= 0;
										a_player2 <= a_player2 + square_length;					
									else
										a_player2 <= a_player2 - 1;
									end if;
								end if;
								if(h_cnt = h_back_porch + square_length + h_var_2_display) then
									double_column_sala <= NOT double_column_sala;
									if(double_column_sala = '0') then
										a_player2 <= a_player2 + sprite_size;
									end if;
								end if;
							end if;
						end if;
					else
						if (player2_state_display(0) = '1') then
							if (NOT (c_player2_jump = "000011110000")) then
								color <= c_player2_jump;
							end if;
							double_line_sala <= NOT double_line_sala;
							if(double_line_sala = '1') then
								a_player2_jump <= a_player2_jump + 1;
							end if;
							if(h_cnt = h_back_porch + square_length + h_var_2_display) then
								double_column_sala <= NOT double_column_sala;
								if(double_column_sala = '0') then
									a_player2_jump <= a_player2_jump - sprite_size;
								end if;
							end if;
						else 
							if (NOT (c_player2_jump = "000011110000")) then
								color <= c_player2_jump;
							end if;
							double_line_sala <= NOT double_line_sala;
							if(double_line_sala = '1') then
								addr_cnt_2 <= addr_cnt_2 + 1;
								if ( addr_cnt_2 = sprite_size ) then
									addr_cnt_2 <= 0;
									a_player2_jump <= a_player2_jump + square_length;					
								else
									a_player2_jump <= a_player2_jump - 1;
								end if;
							end if;
							if(h_cnt = h_back_porch + square_length + h_var_2_display) then
								double_column_sala <= NOT double_column_sala;
								if(double_column_sala = '0') then
									a_player2_jump <= a_player2_jump + sprite_size;
								end if;
							end if;
						end if;
					end if;
				end if;
			end if;
			
			if (game_state_display /= 5) then
				if (game_state_display /= 3) then
					--Generate cooldown bar of 1
					if ( (v_cnt >= v_back_porch + bar_1_pos_y) AND (v_cnt <= v_back_porch + bar_1_pos_y + bar_1_height)
						AND (h_cnt >= h_back_porch + bar_1_pos_x) AND (h_cnt <= h_back_porch + bar_1_pos_x + dash_cooldown_1_display * 3)) then
						if(dash_cooldown_1_display = 100) then
							color <= "000000001111";
						else
							color <= "110011100100"; -- square color
						end if;
					end if;
					--Generate the life bar for 1
					if ( (v_cnt >= v_back_porch + life_1_pos_y) AND (v_cnt <= v_back_porch + life_1_pos_y + life_1_height)
						AND (h_cnt >= h_back_porch + life_1_pos_x) AND (h_cnt < h_back_porch + life_1_pos_x + life_1_display)) then
						if (life_1_display >= 200) then
							color <= "000011110000";
						elsif (life_1_display >= 100) then
							color <= "000000001111";
						else
							color <= "111100000000"; -- square color
						end if;
					end if;
				end if;
			
				if (game_state_display /= 4) then
				--Generate cooldown bar of 2
					if ( (v_cnt >= v_back_porch + bar_2_pos_y) AND (v_cnt <= v_back_porch + bar_2_pos_y + bar_2_height)
						AND (h_cnt >= h_back_porch + bar_2_pos_x + bar_2_length - dash_cooldown_2_display * 3) AND (h_cnt <= h_back_porch + bar_2_pos_x + bar_2_length)) then
						if(dash_cooldown_2_display = 100) then
							color <= "111100000000";
						else
							color <= "010111100100"; -- square color
						end if;
					end if;
						--Generate the life bar for 2
					if ( (v_cnt >= v_back_porch + life_2_pos_y) AND (v_cnt <= v_back_porch + life_2_pos_y + life_2_height)
						AND (h_cnt >= h_back_porch + life_2_pos_x + life_2_length - life_2_display) AND (h_cnt < h_back_porch + life_2_pos_x + life_2_length)) then
						if (life_2_display >= 200) then
							color <= "000011110000";
						elsif (life_2_display >= 100) then
							color <= "000000001111";
						else
							color <= "111100000000"; -- square color
						end if;
					end if;
				end if;
			end if;
		end if;
		
		--generate the display of the boost
		if(boost_active(0) = '1') then
			if ( (v_cnt >= v_back_porch + boost_y_pos) AND (v_cnt <= v_back_porch + boost_y_pos + boost_heigth)
			AND (h_cnt >= h_back_porch + boost_x_pos) AND (h_cnt <= h_back_porch + boost_x_pos + boost_length)) then
				color <= "110011000011";
			end if;
		elsif (boost_active(1) = '1') then
			if ( (v_cnt >= v_back_porch + boost_y_pos) AND (v_cnt <= v_back_porch + boost_y_pos + boost_heigth)
			AND (h_cnt >= h_back_porch + boost_x_pos) AND (h_cnt <= h_back_porch + boost_x_pos + boost_length)) then
				color <= "001111001100";
			end if;
		elsif (boost_active(2) = '1') then
			if ( (v_cnt >= v_back_porch + boost_y_pos) AND (v_cnt <= v_back_porch + boost_y_pos + boost_heigth)
			AND (h_cnt >= h_back_porch + boost_x_pos) AND (h_cnt <= h_back_porch + boost_x_pos + boost_length)) then
				color <= "111100001011";
			end if;
		elsif (boost_active(3) = '1') then
			if ( (v_cnt >= v_back_porch + boost_y_pos) AND (v_cnt <= v_back_porch + boost_y_pos + boost_heigth)
			AND (h_cnt >= h_back_porch + boost_x_pos) AND (h_cnt <= h_back_porch + boost_x_pos + boost_length)) then
				color <= "001100110011";
			end if;
		end if;
		
		--generate the display of the boost when they have been capted for player 1
		if(player1_boost(0) = '1') then
			if ( (v_cnt >= v_back_porch + player1_boost_pos_y) AND (v_cnt <= v_back_porch + player1_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player1_boost_pos_x) AND (h_cnt <= h_back_porch + player1_boost_pos_x + boost_length)) then
				color <= "110011000011";
			end if;
		elsif (player1_boost(1) = '1') then
			if ( (v_cnt >= v_back_porch + player1_boost_pos_y) AND (v_cnt <= v_back_porch + player1_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player1_boost_pos_x) AND (h_cnt <= h_back_porch + player1_boost_pos_x + boost_length)) then
				color <= "001111001100";
			end if;
		elsif (player1_boost(2) = '1') then
			if ( (v_cnt >= v_back_porch + player1_boost_pos_y) AND (v_cnt <= v_back_porch + player1_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player1_boost_pos_x) AND (h_cnt <= h_back_porch + player1_boost_pos_x + boost_length)) then
				color <= "111100001011";
			end if;
		elsif (player2_boost(3) = '1') then
			if ( (v_cnt >= v_back_porch + player1_boost_pos_y) AND (v_cnt <= v_back_porch + player1_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player1_boost_pos_x) AND (h_cnt <= h_back_porch + player1_boost_pos_x + boost_length)) then
				color <= "001100110011";
			end if;
		end if;
		
		--generate the display of the boost when they have been capted for player 2
		if(player2_boost(0) = '1') then
			if ( (v_cnt >= v_back_porch + player2_boost_pos_y) AND (v_cnt <= v_back_porch + player2_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player2_boost_pos_x) AND (h_cnt <= h_back_porch + player2_boost_pos_x + boost_length)) then
				color <= "110011000011";
			end if;
		elsif (player2_boost(1) = '1') then
			if ( (v_cnt >= v_back_porch + player2_boost_pos_y) AND (v_cnt <= v_back_porch + player2_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player2_boost_pos_x) AND (h_cnt <= h_back_porch + player2_boost_pos_x + boost_length)) then
				color <= "001111001100";
			end if;
		elsif (player2_boost(2) = '1') then
			if ( (v_cnt >= v_back_porch + player2_boost_pos_y) AND (v_cnt <= v_back_porch + player2_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player2_boost_pos_x) AND (h_cnt <= h_back_porch + player2_boost_pos_x + boost_length)) then
				color <= "111100001011";
			end if;
		elsif (player1_boost(3) = '1') then
			if ( (v_cnt >= v_back_porch + player2_boost_pos_y) AND (v_cnt <= v_back_porch + player2_boost_pos_y + boost_heigth)
			AND (h_cnt >= h_back_porch + player2_boost_pos_x) AND (h_cnt <= h_back_porch + player2_boost_pos_x + boost_length)) then
				color <= "001100110011";
			end if;
		end if;
		
		--Generate Horizontal Sync
		if (h_cnt <= h_length-1) AND (h_cnt >= h_length - h_sync_length) then
			h_sync <= '0';
		else
			h_sync <= '1';
		end if;

		--Generate Vertical Sync
		if (v_cnt <= v_length-1) AND (v_cnt >= v_length - v_sync_length) then
			v_sync <= '0';
		else
			v_sync <= '1';
		end if;

		--Reset Horizontal Counter
		if (h_cnt = h_length - 1) then
			h_cnt <= "00000000000";
			
		else
			h_cnt <= h_cnt + 1;
		end if;

		--Reset Vertical Counter
		if (v_cnt = v_length - 1) AND (h_cnt = h_length - 1) then
			v_cnt <= "00000000000";
			
			h_var_1_display <= h_var_1;
			v_var_1_display <= v_var_1;
			h_var_2_display <= h_var_2;
			v_var_2_display <= v_var_2;
			
			dash_cooldown_1_display <= dash_cooldown_1;
			dash_cooldown_2_display <= dash_cooldown_2;
			
			life_1_display <= life_1;
			life_2_display <= life_2;
			
			player1_state_display <= player1_state;
			player2_state_display <= player2_state;
			game_state_display <= game_state;
			
			X1_1_display <= X1_1;
			Y1_1_display <= Y1_1;
			X2_1_display <= X2_1;
			Y2_1_display <= Y2_1;
			X1_2_display <= X1_2;
			Y1_2_display <= Y1_2;
			X2_2_display <= X2_2;
			Y2_2_display <= Y2_2;
			
			--reset print signals
			if (player1_state(0) = '1') then
				a_player1 <= "00000000000";
				a_player1_iddle <= "00000000000";
				a_player1_jump <= "00000000000";
			else 
				a_player1 <= "00000100111"; --39	
				a_player1_iddle <= "00000100111"; --39		
				a_player1_jump <= "00000100111"; --39				
			end if;
			
			--reset the walking
			if (player1_state(2) = '0') then
				walk_cnt_1 <= 7;
			else
				walk_cnt_1 <= walk_cnt_1 + 1;
			end if;
			
			--reset print signals
			if (player2_state(0) = '1') then
				a_player2 <= "00000000000";
				a_player2_iddle <= "00000000000";
				a_player2_jump <= "00000000000";
			else 
				a_player2 <= "00000100111"; --39	
				a_player2_iddle <= "00000100111"; --39		
				a_player2_jump <= "00000100111"; --39				
			end if;
			
			--reset the walking
			if (player2_state(2) = '0') then
				walk_cnt_2 <= 7;
			else
				walk_cnt_2 <= walk_cnt_2 + 1;
			end if;
			
			--reset print signals
			if ((dir1_1 = '1') AND (prj_cnt_1 >= prj_cst))then
				a_prj2_1 <= "000000000";
			else 
				a_prj2_1 <= "000011101"; --29				
			end if;
			
			if ((dir2_1 = '1') AND (prj_cnt_1 < prj_cst))then
				a_prj2_2 <= "000000000";
			else 
				a_prj2_2 <= "000011101"; --29					
			end if;
			
			if ((dir1_2 = '1') AND (prj_cnt_2 >= prj_cst))then
				a_prj1_1 <= "000000000";
			else 
				a_prj1_1 <= "000011101"; --29					
			end if;
			
			if ((dir2_2 = '1') AND (prj_cnt_2 < prj_cst))then
				a_prj1_2 <= "000000000";
			else 
				a_prj1_2 <= "000011101"; --29					
			end if;
			
			--reset the projectile animation
			if ((has_shoot1_1 = '0') AND  (has_shoot2_1 = '0')) then
				prj_cnt_1 <= 0;
			else
				prj_cnt_1 <= prj_cnt_1 + 1;
			end if;
			
			if ((has_shoot1_2 = '0') AND (has_shoot2_2 = '0')) then
				prj_cnt_2 <= 0;
			else
				prj_cnt_2 <= prj_cnt_2 + 1;
			end if;
			
		elsif (h_cnt = h_length - 1) then
			v_cnt <= v_cnt + 1;
		end if;

		--Generate Horizontal Data
		if (h_cnt >= 63 AND h_cnt <= 863) then
			horizontal_en <= '1';
		else
			horizontal_en <= '0';
		end if;

		--Generate Vertical Data
		if (v_cnt >= 24 AND v_cnt <= 623) then
			vertical_en <= '1';
		else
			vertical_en <= '0';
		end if;

		--Assign pins to color VGA
		RED(0) <= color(8) AND video_en;   --Red LSB
		RED(1) <= color(9) AND video_en;
		RED(2) <= color(10) AND video_en;
		RED(3) <= color(11) AND video_en;  --Red MSB
		GREEN(0) <= color(4) AND video_en; --Green LSB
		GREEN(1) <= color(5) AND video_en;
		GREEN(2) <= color(6) AND video_en;
		GREEN(3) <= color(7) AND video_en; --Green MSB
		BLUE(0) <= color(0) AND video_en;  --Blue LSB
		BLUE(1) <= color(1) AND video_en;
		BLUE(2) <= color(2) AND video_en;
		BLUE(3) <= color(3) AND video_en;  --Blue MSB

		--Synchro
		SYNC(1) <= h_sync;
		SYNC(0) <= v_sync;

end process vga_display_arch;
end vga_display_arch;