library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.std_logic_misc.all;

entity projectile is 
port	(
			CLK_PROJ : in std_logic;
			DIR : in std_logic;
			Shoot : in std_logic;
			P_X, P_Y : in integer range 0 to 800;
			X0, Y0	: in integer range 0 to 800;
			game_state : in integer range 0 to 10;
			player_nbr : in std_logic;
			X1, Y1, X2, Y2 : buffer integer range 0 to 800;
			hit		: out std_logic;
			dir1		: out std_logic;
			dir2		: out std_logic;
			has_shoot_2 : buffer std_logic;
			has_shoot_1 : buffer std_logic
		);
end entity projectile;

--Projectile Architecture--
architecture proj_arch of projectile is

signal dir_1 : std_logic := '0';
signal dir_2 : std_logic := '0';

signal init : std_logic := '1';
signal game_state_win : integer range 0 to 10;

constant proj_speed : integer := 5;
constant square_length : integer := 79;
constant proj_length : integer := 14;
constant proj_heigth : integer := 29;
constant h_active 		: integer := 800;


begin 


process

begin

	wait until falling_edge(CLK_PROJ);
	
	hit <= '0';
	
	if (game_state = 5) then
		has_shoot_1 <= '0';
		has_shoot_2 <= '0';
	end if;
	
	if(init = '1') then
		
		has_shoot_1 <= '0';
		has_shoot_2 <= '0';
		init <= '0';
		if (player_nbr = '0') then
			game_state_win <= 4;
		else
			game_state_win <= 3;
		end if; 
	
	else
	
		if (Shoot = '1') AND (has_shoot_1 = '0') then
			has_shoot_1 <= '1';
			Y1 <= Y0 + square_length / 3;
			dir_1 <= DIR;
			dir1 <= DIR;
			if (DIR = '0') then
				X1 <= X0 + square_length;
			else
				X1 <= X0;
			end if;
			
		elsif (Shoot = '1') AND (has_shoot_2 = '0') then
			has_shoot_2 <= '1';
			Y2 <= Y0 + square_length / 3;
			dir_2 <= DIR;
			dir2 <= DIR;
			if (DIR = '0') then
				X2 <= X0 + square_length;
			else
				X2 <= X0;
			end if;
			
		end if;
		
		if(has_shoot_1 = '1') then
			
			if(dir_1 = '0') then
				X1 <= X1 + proj_speed;
				
				if (Y1 <= P_Y + square_length) AND (Y1 >= P_Y - proj_heigth)
				AND (X1 <= P_X + square_length) AND (X1 + proj_length >= P_X) AND (game_state /= game_state_win) then
					hit <= '1';
					has_shoot_1 <= '0';
					X1 <= 800;
				elsif (X1 + proj_length > h_active - proj_speed) then
					has_shoot_1 <= '0';
					X1 <= 800;
				end if;
				
			
			else
				X1 <= X1 - proj_speed;
				
				if (Y1 <= P_Y + square_length) AND (Y1 >= P_Y - proj_heigth)
				AND (X1 + proj_length >= P_X ) AND (X1 <= P_X + square_length) AND (game_state /= game_state_win) then
					hit <= '1';
					has_shoot_1 <= '0';
					X1 <= 800;
				elsif (X1 < proj_speed) then
					has_shoot_1 <= '0';
					X1 <= 800;
				end if;
				
			end if;
		end if;
		
		if(has_shoot_2 = '1') then
			
			if(dir_2 = '0') then
				X2 <= X2 + proj_speed;
				
				if (Y2 <= P_Y + square_length) AND (Y2 >= P_Y - proj_heigth)
				AND (X2 <= P_X + square_length) AND (X2 + proj_length >= P_X) AND (game_state /= game_state_win) then
					hit <= '1';
					has_shoot_2 <= '0';
					X2 <= 800;
				elsif (X2 + proj_length > h_active - proj_speed) then
					has_shoot_2 <= '0';
					X2 <= 800;
				end if;
				
			
			else
				X2 <= X2 - proj_speed;
				
				if (Y2 <= P_Y + square_length) AND (Y2 >= P_Y - proj_heigth)
				AND (X2 + proj_length >= P_X ) AND (X2 <= P_X + square_length) AND (game_state /= game_state_win) then
					hit <= '1';
					has_shoot_2 <= '0';
					X2 <= 800;
				elsif (X2 < proj_speed) then
					has_shoot_2 <= '0';
					X2 <= 800;
				end if;
				
			end if;
		end if;
	end if;

end process proj_arch;
end architecture proj_arch;