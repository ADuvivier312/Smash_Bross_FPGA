library ieee;
use ieee.std_logic_1164.ALL;
use ieee.std_logic_ARITH.ALL;
use ieee.std_logic_UNSIGNED.ALL;
use work.ALL;

entity vga is port 
	( 
		CLK_50 : in std_logic;	
		RED: out std_logic_vector(3 downto 0);
		GREEN: out std_logic_vector(3 downto 0);  
		BLUE: out std_logic_vector(3 downto 0); 			
		SYNC: out std_logic_vector(1 downto 0);
	
		L1, L2    : out std_logic := '0';
      CLK_SNES    : buffer std_logic_vector(1 downto 0);
      D1, D2    : in std_logic
	);
end vga;

architecture vga_arch of vga is
	
	--state of the players
	signal player1_state : std_logic_vector(4 downto 0) := "00000";
	signal player2_state : std_logic_vector(4 downto 0) := "00000";
	
	--Sync Counters
	signal h_cnt : std_logic_vector(10 downto 0) := (others => '0');
	signal v_cnt : std_logic_vector (10 downto 0) := (others => '0');
	signal h_var_1 : integer range 0 to 800 := 200;
	signal v_var_1 : integer range 0 to 600 := 533;
	signal h_var_2 : integer range 0 to 800 := 200;
	signal v_var_2 : integer range 0 to 600 := 533;
	
	--Counter to limit the Dash
	signal dash_cooldown_1 : integer range 0 to 150 := 0;
	signal dash_cooldown_2 : integer range 0 to 150 := 0;
	
	--life of players
	signal life_1 : integer range 0 to 350 := 350;
	signal life_2 : integer range 0 to 350 := 350;
	
   signal ctrl1, ctrl2                 : std_logic_vector(11 downto 0);
	
	signal clk_player : std_logic := '0';
	
	--signal for the state of the game
	signal game_state : integer range 0 to 10 := 0;
	
	--signal for the shoot
	signal shoot_1 : std_logic;
	signal shoot_2 : std_logic;
	
	--signals for the projectile
	signal X1_1, Y1_1, X2_1, Y2_1, X1_2, Y1_2, X2_2, Y2_2  : integer range 0 to 800;
	signal X1_1_display, Y1_1_display, X2_1_display, Y2_1_display : integer range 0 to 800;
	signal X1_2_display, Y1_2_display, X2_2_display, Y2_2_display : integer range 0 to 800;
	signal hit_1, hit_2 : std_logic;
	signal dir1_1, dir1_2, dir2_1, dir2_2 : std_logic;
	signal has_shoot1_1, has_shoot2_1, has_shoot1_2, has_shoot2_2 : std_logic;
	
	--signals for the boost
	signal player1_boost : std_logic_vector(3 downto 0) := "0000";
	signal player2_boost : std_logic_vector(3 downto 0) := "0000";
	signal boost_x_pos : integer range 0 to 800;
	signal boost_y_pos : integer range 0 to 600;
	signal boost_active : std_logic_vector(3 downto 0) := "0000";
	
begin

	game_state_ent : entity work.game_state
	 port map(   ctrl1   =>  ctrl1,
					 ctrl2   =>  ctrl2,
					 CLK  =>  clk_player,
					 life_player_1 => life_1,
					 life_player_2 => life_2,
					 game_state  => game_state
					);
	
	ctrl_1_ent : entity work.snes
    port map(    CLK    => CLK_SNES(0),
                    DATA         => D1,
                    LATCH        => L1,
                    CONTROL     => ctrl1
                );
					 
	 ctrl_2_ent : entity work.snes
    port map(    CLK    => CLK_SNES(1),
                    DATA         => D2,
                    LATCH        => L2,
                    CONTROL     => ctrl2
                );

    clocks_ent : entity work.clocks
    port map(    CLK_50         => CLK_50,
                    CLK_SNES     => CLK_SNES,
						  CLK_PLAYER   => clk_player
                );
					 
	 player1_ent : entity work.player
	 port map(     CLK_player     =>  clk_player,
						ctrl           => ctrl1,
						player_nbr     => '0',
						other_player_x => h_var_2,
						other_player_y => v_var_2,
						game_state     => game_state,
						hit 				=> hit_1,
						boost				=> player1_boost,
						h_var          => h_var_1,
						v_var          => v_var_1,
						dash_cooldown  => dash_cooldown_1,
						other_player_life    => life_2,
						player_state   => player1_state,
						shoot				=> shoot_1
					);
					
	 player2_ent : entity work.player
	 port map(     CLK_player     =>  clk_player,
						ctrl           => ctrl2,
						player_nbr     => '1',
						other_player_x => h_var_1,
						other_player_y => v_var_1,
						game_state     => game_state,
						hit 				=> hit_2,
						boost				=> player2_boost,
						h_var          => h_var_2,
						v_var          => v_var_2,
						dash_cooldown  => dash_cooldown_2,
						other_player_life     => life_1,
						player_state   => player2_state,
						shoot				=> shoot_2
					);
					
	proj_1 : entity work.projectile
	port map (    	CLK_PROJ    => clk_player,
						DIR			=> player1_state(0),
						Shoot       => shoot_1,
						P_X 			=> h_var_2,
						P_Y    		=> v_var_2,
						X0 			=> h_var_1,
						Y0          => v_var_1,
						game_state  => game_state,
						player_nbr  => '0',
						X1  			=> X1_1,
						Y1				=> Y1_1,
						X2				=> X2_1,
						Y2				=> Y2_1,
						hit			=> hit_1,
						dir1			=> dir1_1,
						dir2			=> dir1_2,
						has_shoot_1	=> has_shoot1_1,
						has_shoot_2	=> has_shoot2_1
				);
	
	proj_2 : entity work.projectile
	port map (    	CLK_PROJ    => clk_player,
						DIR			=> player2_state(0),
						Shoot       => shoot_2,
						P_X 			=> h_var_1,
						P_Y    		=> v_var_1,
						X0 			=> h_var_2,
						Y0          => v_var_2,
						game_state  => game_state,
						player_nbr  => '1',
						X1  			=> X1_2,
						Y1				=> Y1_2,
						X2				=> X2_2,
						Y2				=> Y2_2,
						hit			=> hit_2,
						dir1			=> dir2_1,
						dir2			=> dir2_2,
						has_shoot_1	=> has_shoot1_2,
						has_shoot_2	=> has_shoot2_2
				);

	boost : entity work.boost
	port map(	ctrl1			=> ctrl1,
					ctrl2			=> ctrl2,
					CLK_BOOST	=>	clk_player,
					player1_x	=> h_var_1,
					player1_y 	=> v_var_1,
					player2_x	=> h_var_2,
					player2_y	=> v_var_2,
					game_state	=> game_state,
					player1_boost_output => player1_boost,
					player2_boost_output => player2_boost,
					boost_x   	=> boost_x_pos,
					boost_y  	=> boost_y_pos,
					boost_active  => boost_active
				);
				
	vga_display : entity work.vga_display
	port map(	CLK_50 		=> CLK_50,
					RED			=>	RED,
					GREEN			=>	GREEN,
					BLUE			=> BLUE,
					SYNC			=>	SYNC,
					player1_state	=>	player1_state,
					player2_state	=> player2_state,
					dash_cooldown_1	=>	dash_cooldown_1,
					dash_cooldown_2	=>	dash_cooldown_2,
					life_1		=> life_1,
					life_2		=>	life_2,
					h_var_1		=>	h_var_1,
					v_var_1		=>	v_var_1,
					h_var_2		=>	h_var_2,
					v_var_2		=>	v_var_2,
					game_state	=>	game_state,
					X1_1 => X1_1, Y1_1 => Y1_1, X2_1 => X2_1, Y2_1 => Y2_1,
					X1_2 => X1_2, Y1_2 => Y1_2, X2_2 => X2_2, Y2_2 => Y2_2,
					dir1_1 => dir1_1, dir1_2 => dir1_2,
					dir2_1 => dir2_1, dir2_2 => dir2_2,
					has_shoot1_1 => has_shoot1_1, has_shoot2_1 => has_shoot2_1,
					has_shoot1_2 => has_shoot1_2, has_shoot2_2 => has_shoot2_2,
					player1_boost	=> player1_boost,
					player2_boost	=> player2_boost,
					boost_x_pos		=> boost_x_pos,
					boost_y_pos		=> boost_y_pos,
					boost_active	=> boost_active
				);
end vga_arch;